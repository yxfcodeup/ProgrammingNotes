from grab.spider import Spider

class FirstSpider(Spider):
    pass
