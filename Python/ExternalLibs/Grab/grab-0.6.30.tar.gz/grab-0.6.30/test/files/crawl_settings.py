GRAB_SPIDER_CONFIG = {
    'global': {
        'spider_modules': ['test.script_crawl'],
    },
}
