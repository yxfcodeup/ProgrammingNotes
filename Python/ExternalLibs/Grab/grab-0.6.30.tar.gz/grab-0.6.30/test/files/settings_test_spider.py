GRAB_SPIDER_CONFIG = {
    'global': {
        'spider_modules': ['zzz'],
    },
    'test_spider': {
        'thread_number': 777,
    },
}
