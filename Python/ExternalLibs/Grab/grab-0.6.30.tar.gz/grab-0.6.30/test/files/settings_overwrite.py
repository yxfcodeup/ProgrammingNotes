GRAB_SPIDER_CONFIG = {
    'global': {
        'spider_modules': ['zzz'],
    },
}
