# Back-ward compatibility
from grab.document import *  # noqa
from grab.document import Document as Response  # noqa
