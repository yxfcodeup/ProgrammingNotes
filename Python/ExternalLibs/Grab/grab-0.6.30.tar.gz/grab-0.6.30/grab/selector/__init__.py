import logging
from grab.selector.selector import *  # noqa
from grab.util.warning import warn

warn('Module `grab.selector` is deprecated. Use `selection` package.')
